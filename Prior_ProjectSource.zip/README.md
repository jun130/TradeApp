# TradeApp-TeamProject

software design and experiment _ 13's group
