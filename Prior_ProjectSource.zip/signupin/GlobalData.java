package com.example.signupin;

public class GlobalData {
        public static String Myemail =  "";
        public static String MyName =  "";

        public static String getMyemail() {
                return Myemail;
        }

        public static void setMyemail(String myemail) {
                Myemail = myemail;
        }

        public static String getMyName() {
                return MyName;
        }

        public static void setMyName(String myName) {
                MyName = myName;
        }
}
