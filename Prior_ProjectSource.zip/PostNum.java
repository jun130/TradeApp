package com.example.signupin;

public class PostNum {
    public int postnum = 0;

    public PostNum() {
    }
    public PostNum (int i) { this.postnum = i; }

    public int getPostnum() {
        return postnum;
    }

    public void setPostnum(int postnum) {
        this.postnum = postnum;
    }
}
