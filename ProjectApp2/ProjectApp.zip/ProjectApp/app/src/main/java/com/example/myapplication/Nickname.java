package com.example.myapplication;

public class Nickname {
    public String nickname = "";

    public Nickname(){

    }

    public Nickname(String s){
        this.nickname = s;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    /*

    public static String nickname = "";

    public Nickname () {

    }
    */
}

