package com.example.myapplication;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;



public class MainActivity extends AppCompatActivity {
    private Button Chatbtn;
    private Button Listbtn;
    private EditText editText;
    private EditText editText2;
    private EditText editText01;
    private EditText editText02;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /*
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Listbtn= (Button) findViewById(R.id.listbtn);
        Chatbtn = (Button) findViewById(R.id.chatbtn);
        editText = (EditText) findViewById(R.id.idinput);
        editText2 = (EditText) findViewById(R.id.idinput2);
        editText01 = (EditText) findViewById(R.id.idinput01);
        editText02 = (EditText) findViewById(R.id.idinput02);

        Listbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),ListActivity.class);
                GlobalData.Myemail = editText.getText().toString();
                GlobalData.Otheremail = editText2.getText().toString();
                GlobalData.MyName = editText01.getText().toString();
                GlobalData.OtherName = editText02.getText().toString();
                startActivity(intent);

            }
        });

        Chatbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(),ChatActivity.class);
                GlobalData.Myemail = editText.getText().toString();
                GlobalData.Otheremail = editText2.getText().toString();
                GlobalData.MyName = editText01.getText().toString();
                GlobalData.OtherName = editText02.getText().toString();
                startActivity(intent);

            }
        });
*/
    }




}