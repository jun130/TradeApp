package com.example.myapplication;

public class GlobalData {
    public static String MyName = "";
    public static String OtherName = "";
    public static String Myemail = "";
    public static String Otheremail = "";
    public static int PostNum;

    public static int getPostNum() {
        return PostNum;
    }

    public static void setPostNum(int postNum) {
        PostNum = postNum;
    }
}

